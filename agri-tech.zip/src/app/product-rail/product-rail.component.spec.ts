import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductRailComponent } from './product-rail.component';

describe('ProductRailComponent', () => {
  let component: ProductRailComponent;
  let fixture: ComponentFixture<ProductRailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductRailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductRailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
