export class MyData  {
  public beth(){
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": ""
        }
      ],
      "available": [
        {
          "available": true,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": ""
        },
        {
          "available": true,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }
  public hex() {
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": ""
        }
      ],
      "available": [
        {
          "available": true,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": ""
        },
        {
          "available": true,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }

  public hen(){
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": ""
        }
      ],
      "available": [
        {
          "available": true,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": ""
        },
        {
          "available": true,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": true,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }
}
