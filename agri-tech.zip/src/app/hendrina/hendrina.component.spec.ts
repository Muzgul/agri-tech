import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HendrinaComponent } from './hendrina.component';

describe('HendrinaComponent', () => {
  let component: HendrinaComponent;
  let fixture: ComponentFixture<HendrinaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HendrinaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HendrinaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
