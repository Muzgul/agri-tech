import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'agt-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit {

  @Input () productName: string;
  @Input () productDescription: string;
  @Input () productAvailable: boolean;
  @Input () productUrl: string;
  @Input () productType: string;
  
  available: string;
  type: string;
  hidden: string = "";

  constructor() { }

  ngOnInit() {
    if (this.productAvailable == true)
      this.available = "";
    else
      this.available = "disabled";
    if (this.productType == "purchased")
      this.type = "Open";
    else
    {
      this.type = "";
      this.hidden = "hidden";
    }
  }

}
