import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'agt-product-card',
  templateUrl: './product-card.component.html',
  styleUrls: ['./product-card.component.css']
})
export class ProductCardComponent implements OnInit {

  @Input () productName: string;
  @Input () productDescription: string;
  @Input () productAvailable: boolean;
  @Input () productUrl: string;
  @Input () productType: string;
  
  available: string = "disabled";
  type: string;
  hidden: string = "";
  animate: string = "";

  constructor() { }

  ngOnInit() {
    if (this.productAvailable == true)
      this.available = "";
    if (this.productType == "purchased")
      this.type = "Open";
    else
    {
      this.type = "";
      this.hidden = "hidden";
    }

    if (this.productName == "Soil Moisture Monitoring")
      this.type = "product-card-moist";
    if (this.productName == "Soil Temperature Monitoring")
      this.type = "product-card-temp";
    if (this.productName == "Chill Units Monitoring")
      this.type = "product-card-chill";
    if (this.productName == "Heat Units Monitoring")
      this.type = "product-card-heat";
    if (this.productName == "Pivot Monitoring")
      this.type = "product-card-pivot";
  }

  changeStyle($event){
    this.animate = $event.type == 'mouseover' ? 'product-description-dissapear' : '';
  }

}
