import { Component, OnInit } from '@angular/core';
import { MyData } from "../mydata";
import { Product } from '../model/product';

@Component({
  selector: 'app-bethlehem',
  templateUrl: './bethlehem.component.html',
  styleUrls: ['./bethlehem.component.css']
})
export class BethlehemComponent {

  private bethlehem = null;
  private purchased =  null;
  private available = null;

  constructor(){
    this.bethlehem = new MyData().beth();
    this.purchased = new Array();
    this.available = new Array();
  }

  ngOnInit() {
    this.bethlehem['current'].forEach(element => {
      console.log(element);
      this.purchased.unshift(
        new Product(element.available, element.name, element.description, element.url)
      )
    });

    this.purchased.sort(function (a, b) {return b.available - a.available});

    this.bethlehem['available'].forEach(element => {
      this.available.unshift(
        new Product(element.available, element.name, element.description, element.url)
      );
    });

    this.available.sort(function (a, b) {return b.available - a.available});
  }
}
