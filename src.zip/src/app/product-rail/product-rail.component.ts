import { Component, OnInit, Input } from '@angular/core';
import { Product } from '../model/product';

@Component({
  selector: 'agt-product-rail',
  templateUrl: './product-rail.component.html',
  styleUrls: ['./product-rail.component.css']
})

export class ProductRailComponent implements OnInit {

  @Input () products: Product[];
  @Input () purchased: string;

  constructor() { }

  ngOnInit() {

  }

}
