import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BethlehemComponent } from './bethlehem.component';

describe('BethlehemComponent', () => {
  let component: BethlehemComponent;
  let fixture: ComponentFixture<BethlehemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BethlehemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BethlehemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
