import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule} from "@angular/common/http";

import { AppComponent } from './app.component';
import {RouterModule} from "@angular/router";
import { HexrivierComponent } from './hexrivier/hexrivier.component';
import { HendrinaComponent } from './hendrina/hendrina.component';
import { BethlehemComponent } from './bethlehem/bethlehem.component';
import { ProductCardComponent } from "./product-card/product-card.component";
import { ProductRailComponent } from "./product-rail/product-rail.component";

@NgModule({
  declarations: [
    AppComponent,
    HexrivierComponent,
    HendrinaComponent,
    BethlehemComponent,
    ProductRailComponent,
    ProductCardComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    RouterModule.forRoot([
      {
        path: 'Denau_Farm',
        component: HexrivierComponent
      },
      {
        path: 'WA_de_Klerk_Farm',
        component: HendrinaComponent
      },
      {
        path: 'ARC_Small_Grain_Farm',
        component: BethlehemComponent
      }
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
