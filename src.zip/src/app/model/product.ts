export class Product {
  available: boolean;
  name: string;
  description: string;
  url: string;

  constructor(available: boolean, name: string, description: string, url: string) {
      this.available = available;
      this.name = name;
      this.description = description;
      this.url = url;
  }
}