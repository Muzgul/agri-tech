export class MyData  {
  public beth(){
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": "https://bethlehem-soil-temp-monitoring.run.aws-usw02-pr.ice.predix.io/"
        },
        {
          "available": true,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": "https://bethlehem-soilmoisture-monitoring.run.aws-usw02-pr.ice.predix.io/#/home"
        }
      ],
      "available": [
        {
          "available": false,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": ""
        },
        {
          "available": false,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": false,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }
  public hex() {
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": "https://hexriver-soil-temp-monitoring.run.aws-usw02-pr.ice.predix.io/"
        },
        {
          "available": true,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": "https://hexrivier-soilmoisture-monitoring.run.aws-usw02-pr.ice.predix.io/#/home"
        }
      ],
      "available": [
        {
          "available": false,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": ""
        },
        {
          "available": false,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": false,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }

  public hen(){
    return {
      "current": [
        {
          "available": true,
          "name": "Soil Temperature Monitoring",
          "description": "Monitors the temperature levels in the soil at various depths to ensure that seed are planted at the most appropriate temperature to maximize crop quality and yield.",
          "url": "https://hendrina-soil-temp-monitoring.run.aws-usw02-pr.ice.predix.io/"
        },
        {
          "available": true,
          "name": "Pivot Monitoring",
          "description": "Monitors the tyre pressure on the tyres of irrigation systems to avoid unnecessary downtime and damage to the gearboxes.",
          "url": "https://bcx-pivot-management-hendrina.run.aws-usw02-pr.ice.predix.io/#/home"
        }
      ],
      "available": [
        {
          "available": false,
          "name": "Soil Moisture Monitoring",
          "description": "Monitors the moisture levels in the soil at various depths to ensure irrigation is applied with precision to avoid water wastage.",
          "url": ""
        },
        {
          "available": false,
          "name": "Heat Units Monitoring",
          "description": "Monitors the total amount of heat units a crop is exposed to. Planting crops at the correct heat unit level maximize potential yield.",
          "url": ""
        },
        {
          "available": false,
          "name": "Chill Units Monitoring",
          "description": "Monitors the total amount of chill units a crop is exposed to. Planting crops at the correct chill unit level maximize potential yield.",
          "url": ""
        }
      ]
    };
  }
}
