import { Component } from '@angular/core';
import {MyData} from "../mydata";
import { Product } from '../model/product';

@Component({
  selector: 'app-hendrina',
  templateUrl: './hendrina.component.html',
  styleUrls: ['./hendrina.component.css']
})
export class HendrinaComponent {
  private hendrina = null;
  public purchased =  null;
  public available = null;

  constructor(){
    this.hendrina = new MyData().hen();
    this.purchased = new Array();
    this.available = new Array();
  }

  ngOnInit() {
    this.hendrina['current'].forEach(element => {
      console.log(element);
      this.purchased.unshift(
        new Product(element.available, element.name, element.description, element.url)
      )
    });

    this.purchased.sort(function (a, b) {return b.available - a.available});

    this.hendrina['available'].forEach(element => {
      this.available.unshift(
        new Product(element.available, element.name, element.description, element.url)
      );
    });

    this.available.sort(function (a, b) {return b.available - a.available});
  }
}
