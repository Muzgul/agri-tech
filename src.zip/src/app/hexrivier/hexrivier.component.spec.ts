import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HexrivierComponent } from './hexrivier.component';

describe('HexrivierComponent', () => {
  let component: HexrivierComponent;
  let fixture: ComponentFixture<HexrivierComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HexrivierComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HexrivierComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
