import { Component } from '@angular/core';
import {MyData} from "../mydata";
import { Product } from '../model/product';

@Component({
  selector: 'app-hexrivier',
  templateUrl: './hexrivier.component.html',
  styleUrls: ['./hexrivier.component.css']
})
export class HexrivierComponent {
  private hexriver = null;
  public purchased =  null;
  public available = null;

  constructor(){
    this.hexriver = new MyData().hex();
    this.purchased = new Array();
    this.available = new Array();
  }

  ngOnInit() {
    this.hexriver['current'].forEach(element => {
      console.log(element);
      this.purchased.unshift(
        new Product(element.available, element.name, element.description, element.url)
      )
    });

    this.purchased.sort(function (a, b) {return b.available - a.available});

    this.hexriver['available'].forEach(element => {
      this.available.unshift(
        new Product(element.available, element.name, element.description, element.url)
      );
    });

    this.available.sort(function (a, b) {return b.available - a.available});
  }
}
